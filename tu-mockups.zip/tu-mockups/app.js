// Main Application Logic

class TerminologyApp {
    constructor() {
        this.currentView = 'concepts';
        this.currentItem = null;
        this.editingItem = null;
        this.selectedRowId = null;
        
        this.initializeApp();
    }
    
    initializeApp() {
        this.setupEventListeners();
        this.renderCurrentView();
        this.populateConceptFilter();
    }
    
    setupEventListeners() {
        // Toggle switch
        document.querySelectorAll('input[name="view-toggle"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.switchView(e.target.value);
            });
        });
        
        // Add item button
        document.getElementById('add-item-btn').addEventListener('click', () => {
            this.showAddItemModal();
        });
        
        // Search input
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.filterItems(e.target.value);
        });
        
        // Sort select
        document.getElementById('sort-select').addEventListener('change', (e) => {
            this.sortItems(e.target.value);
        });
        
        // Filter select (for terms)
        document.getElementById('filter-select').addEventListener('change', (e) => {
            this.filterItemsByConcept(e.target.value);
        });
        
        // Edit item button
        document.getElementById('edit-item-btn').addEventListener('click', () => {
            this.toggleEditMode();
        });
        
        // Modal events
        document.getElementById('modal-close').addEventListener('click', () => {
            this.hideModal();
        });
        
        document.getElementById('modal-cancel').addEventListener('click', () => {
            this.hideModal();
        });
        
        document.getElementById('modal-save').addEventListener('click', () => {
            this.saveModal();
        });
        
        // Close modal on overlay click
        document.getElementById('modal-overlay').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                this.hideModal();
            }
        });
    }
    
    switchView(viewName) {
        this.currentView = viewName;
        this.currentItem = null;
        this.selectedRowId = null;
        
        // Update UI elements
        document.getElementById('panel-title').textContent = viewName === 'concepts' ? 'Concepts' : 'Terms';
        document.getElementById('add-item-text').textContent = viewName === 'concepts' ? 'Concept' : 'Term';
        document.getElementById('search-input').placeholder = `Search ${viewName}...`;
        
        // Show/hide filter select for terms
        const filterSelect = document.getElementById('filter-select');
        if (viewName === 'terms') {
            filterSelect.classList.remove('hidden');
        } else {
            filterSelect.classList.add('hidden');
        }
        
        // Clear details panel
        this.clearDetailsPanel();
        
        // Render current view
        this.renderCurrentView();
    }
    
    renderCurrentView() {
        if (this.currentView === 'concepts') {
            this.renderConceptsTable();
        } else {
            this.renderTermsTable();
        }
    }
    
    clearDetailsPanel() {
        document.getElementById('details-title').textContent = 'Select an item to view details';
        document.getElementById('edit-item-btn').disabled = true;
        document.getElementById('details-content').innerHTML = `
            <div class="empty-details">
                <span class="material-icons">info</span>
                <h3>No item selected</h3>
                <p>Select a concept or term from the list to view its details.</p>
            </div>
        `;
    }
    
    // Table Rendering
    renderConceptsTable() {
        const concepts = dataUtils.getAllConcepts();
        this.renderTable(concepts, 'concept');
    }
    
    renderTermsTable() {
        const terms = dataUtils.getAllTerms();
        this.renderTable(terms, 'term');
    }
    
    renderTable(items, type) {
        const tableHeader = document.getElementById('table-header');
        const tableBody = document.getElementById('table-body');
        
        // Set table headers
        if (type === 'concept') {
            tableHeader.innerHTML = `
                <th>Name</th>
                <th>Description</th>
                <th>Terms Count</th>
                <th>Usage Context</th>
                <th>Confidence</th>
            `;
        } else {
            tableHeader.innerHTML = `
                <th>Term</th>
                <th>Original Term</th>
                <th>Definition</th>
                <th>Usage Context</th>
                <th>Confidence</th>
            `;
        }
        
        // Render table rows
        if (items.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="${type === 'concept' ? '5' : '5'}" class="text-center">
                        <div class="empty-state">
                            <span class="material-icons">${type === 'concept' ? 'category' : 'label'}</span>
                            <h3>No ${type}s found</h3>
                            <p>Try adjusting your search or add a new ${type}.</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = items.map(item => {
            const isSelected = this.selectedRowId === item.id;
            const rowClass = isSelected ? 'selected' : '';
            
            if (type === 'concept') {
                return `
                    <tr class="${rowClass}" data-item-id="${item.id}" data-item-type="concept">
                        <td>
                            <div class="table-cell-title">${item.conceptName}</div>
                        </td>
                        <td>
                            <div class="table-cell-description">${item.conceptDescription}</div>
                        </td>
                        <td>
                            <div class="table-cell-subtitle">${item.terms.length} terms</div>
                        </td>
                        <td>
                            <div class="table-cell-subtitle">${item.usageContext}</div>
                        </td>
                        <td>
                            <span class="${dataUtils.getConfidenceBadgeClass(item.confidenceScore)}">
                                ${dataUtils.getConfidencePercentage(item.confidenceScore)}%
                            </span>
                        </td>
                    </tr>
                `;
            } else {
                return `
                    <tr class="${rowClass}" data-item-id="${item.id}" data-item-type="term">
                        <td>
                            <div class="table-cell-title">${item.term}</div>
                            ${item.altTerms.length > 0 ? `
                                <div class="table-cell-subtitle">Alt: ${item.altTerms.slice(0, 2).join(', ')}${item.altTerms.length > 2 ? '...' : ''}</div>
                            ` : ''}
                        </td>
                        <td>
                            <div class="table-cell-subtitle">${item.originalTerm}</div>
                        </td>
                        <td>
                            <div class="table-cell-description">${item.definition}</div>
                        </td>
                        <td>
                            <div class="table-cell-subtitle">${item.usageContext}</div>
                        </td>
                        <td>
                            <span class="${dataUtils.getConfidenceBadgeClass(item.confidenceScore)}">
                                ${dataUtils.getConfidencePercentage(item.confidenceScore)}%
                            </span>
                        </td>
                    </tr>
                `;
            }
        }).join('');
        
        // Add click event listeners to table rows
        this.addTableRowListeners();
    }
    
    addTableRowListeners() {
        const tableRows = document.querySelectorAll('#table-body tr[data-item-id]');
        tableRows.forEach(row => {
            row.addEventListener('click', (e) => {
                const itemId = row.dataset.itemId;
                const itemType = row.dataset.itemType;
                this.selectItem(itemId, itemType);
            });
        });
    }
    
    selectItem(itemId, type) {
        this.selectedRowId = itemId;
        this.currentItem = type === 'concept' ? dataUtils.getConceptById(itemId) : dataUtils.getTermById(itemId);
        
        // Update table selection
        document.querySelectorAll('#table-body tr').forEach(row => {
            row.classList.remove('selected');
        });
        
        // Find and select the clicked row
        const clickedRow = document.querySelector(`tr[data-item-id="${itemId}"]`);
        if (clickedRow) {
            clickedRow.classList.add('selected');
        }
        
        // Show details
        this.showItemDetails(this.currentItem, type);
    }
    
    showItemDetails(item, type) {
        document.getElementById('details-title').textContent = type === 'concept' ? item.conceptName : item.term;
        document.getElementById('edit-item-btn').disabled = false;
        this.isEditing = false;
        
        if (type === 'concept') {
            this.renderConceptDetails(item);
        } else {
            this.renderTermDetails(item);
        }
    }
    
    renderConceptDetails(concept) {
        if (this.isEditing) {
            this.renderConceptEditForm(concept);
        } else {
            document.getElementById('details-content').innerHTML = `
                <div class="details-card">
                    <h3>Concept Information</h3>
                    <div class="details-info">
                        <div class="form-group">
                            <label>Concept Name</label>
                            <div class="form-control">${concept.conceptName}</div>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <div class="form-control">${concept.conceptDescription}</div>
                        </div>
                        <div class="form-group">
                            <label>Usage Context</label>
                            <div class="form-control">${concept.usageContext}</div>
                        </div>
                        <div class="form-group">
                            <label>Confidence Score</label>
                            <div class="form-control">
                                <span class="${dataUtils.getConfidenceBadgeClass(concept.confidenceScore)}">
                                    ${dataUtils.getConfidencePercentage(concept.confidenceScore)}%
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="details-card">
                    <div class="terms-header">
                        <h3>Terms in Concept</h3>
                        <button class="btn btn-primary btn-small" id="add-terms-to-concept-btn">
                            <span class="material-icons">add</span>
                            Add Terms
                        </button>
                    </div>
                    <div class="terms-list">
                        ${concept.terms.length > 0 ? concept.terms.map(term => `
                            <div class="term-item">
                                <div class="term-item-content">
                                    <div class="term-item-title">${term.term}</div>
                                    <div class="term-item-description">${term.definition}</div>
                                </div>
                                <div class="term-item-actions">
                                    <button class="btn btn-small btn-danger" data-term-name="${term.term}">
                                        <span class="material-icons">remove</span>
                                        Remove
                                    </button>
                                </div>
                            </div>
                        `).join('') : `
                            <div class="empty-details">
                                <span class="material-icons">label</span>
                                <h3>No terms in this concept</h3>
                                <p>Add terms to this concept to get started.</p>
                            </div>
                        `}
                    </div>
                </div>
            `;
            
            // Add event listeners for remove buttons and add terms button
            this.addRemoveButtonListeners();
            this.addAddTermsButtonListener();
        }
    }
    
    renderConceptEditForm(concept) {
        document.getElementById('details-content').innerHTML = `
            <div class="details-card">
                <h3>Edit Concept</h3>
                <form id="concept-edit-form" class="edit-form">
                    <div class="form-group">
                        <label for="edit-concept-name">Concept Name</label>
                        <input type="text" id="edit-concept-name" value="${concept.conceptName}" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-concept-description">Description</label>
                        <textarea id="edit-concept-description" required>${concept.conceptDescription}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit-concept-usage">Usage Context</label>
                        <input type="text" id="edit-concept-usage" value="${concept.usageContext}" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-concept-confidence">Confidence Score</label>
                        <input type="number" id="edit-concept-confidence" min="0" max="1" step="0.01" value="${concept.confidenceScore}">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" id="cancel-edit-btn">
                            <span class="material-icons">cancel</span>
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <span class="material-icons">save</span>
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        `;
        
        // Add form event listeners
        this.addConceptEditFormListeners();
    }
    
    renderTermDetails(term) {
        if (this.isEditing) {
            this.renderTermEditForm(term);
        } else {
            document.getElementById('details-content').innerHTML = `
                <div class="details-card">
                    <h3>Term Information</h3>
                    <div class="details-info">
                        <div class="form-group">
                            <label>Original Term</label>
                            <div class="form-control">${term.originalTerm}</div>
                        </div>
                        <div class="form-group">
                            <label>Term Name</label>
                            <div class="form-control">${term.term}</div>
                        </div>
                        <div class="form-group">
                            <label>Alternative Terms</label>
                            <div class="form-control">${term.altTerms.join(', ')}</div>
                        </div>
                        <div class="form-group">
                            <label>Definition</label>
                            <div class="form-control">${term.definition}</div>
                        </div>
                        <div class="form-group">
                            <label>Usage Context</label>
                            <div class="form-control">${term.usageContext}</div>
                        </div>
                        <div class="form-group">
                            <label>Notes</label>
                            <div class="form-control">${term.additionalContext.notes}</div>
                        </div>
                        <div class="form-group">
                            <label>Examples</label>
                            <div class="form-control">${term.additionalContext.examples}</div>
                        </div>
                        <div class="form-group">
                            <label>Related Terms</label>
                            <div class="form-control">${term.additionalContext.relatedTerms.join(', ')}</div>
                        </div>
                        <div class="form-group">
                            <label>Confidence Score</label>
                            <div class="form-control">
                                <span class="${dataUtils.getConfidenceBadgeClass(term.confidenceScore)}">
                                    ${dataUtils.getConfidencePercentage(term.confidenceScore)}%
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
    }
    
    renderTermEditForm(term) {
        document.getElementById('details-content').innerHTML = `
            <div class="details-card">
                <h3>Edit Term</h3>
                <form id="term-edit-form" class="edit-form">
                    <div class="form-group">
                        <label for="edit-term-original">Original Term</label>
                        <input type="text" id="edit-term-original" value="${term.originalTerm}" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-term-name">Term Name</label>
                        <input type="text" id="edit-term-name" value="${term.term}" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-term-alt">Alternative Terms (comma-separated)</label>
                        <input type="text" id="edit-term-alt" value="${term.altTerms.join(', ')}" placeholder="alt1, alt2, alt3">
                    </div>
                    <div class="form-group">
                        <label for="edit-term-definition">Definition</label>
                        <textarea id="edit-term-definition" required>${term.definition}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit-term-usage">Usage Context</label>
                        <input type="text" id="edit-term-usage" value="${term.usageContext}" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-term-notes">Notes</label>
                        <textarea id="edit-term-notes">${term.additionalContext.notes}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit-term-examples">Examples</label>
                        <textarea id="edit-term-examples">${term.additionalContext.examples}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit-term-related">Related Terms (comma-separated)</label>
                        <input type="text" id="edit-term-related" value="${term.additionalContext.relatedTerms.join(', ')}" placeholder="term1, term2, term3">
                    </div>
                    <div class="form-group">
                        <label for="edit-term-confidence">Confidence Score</label>
                        <input type="number" id="edit-term-confidence" min="0" max="1" step="0.01" value="${term.confidenceScore}">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" id="cancel-edit-btn">
                            <span class="material-icons">cancel</span>
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <span class="material-icons">save</span>
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        `;
        
        // Add form event listeners
        this.addTermEditFormListeners();
    }
    
    // Filtering and Sorting
    filterItems(query) {
        if (this.currentView === 'concepts') {
            const filtered = dataUtils.searchConcepts(query);
            this.renderTable(filtered, 'concept');
        } else {
            const filtered = dataUtils.searchTerms(query);
            this.renderTable(filtered, 'term');
        }
    }
    
    sortItems(sortBy) {
        if (this.currentView === 'concepts') {
            const concepts = dataUtils.getAllConcepts();
            const sorted = dataUtils.sortConcepts(concepts, sortBy);
            this.renderTable(sorted, 'concept');
        } else {
            const terms = dataUtils.getAllTerms();
            const sorted = dataUtils.sortTerms(terms, sortBy);
            this.renderTable(sorted, 'term');
        }
    }
    
    filterItemsByConcept(conceptId) {
        if (this.currentView === 'terms') {
            const terms = dataUtils.getAllTerms();
            const filtered = dataUtils.filterTermsByConcept(terms, conceptId);
            this.renderTable(filtered, 'term');
        }
    }
    
    populateConceptFilter() {
        const select = document.getElementById('concept-filter');
        if (select) {
            const concepts = dataUtils.getAllConcepts();
            
            select.innerHTML = '<option value="">All Concepts</option>' +
                concepts.map(concept => 
                    `<option value="${concept.id}">${concept.conceptName}</option>`
                ).join('');
        }
    }
    
    addRemoveButtonListeners() {
        const removeButtons = document.querySelectorAll('[data-term-name]');
        removeButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                const termName = button.dataset.termName;
                this.removeTermFromConcept(termName);
            });
        });
    }
    
    addAddTermsButtonListener() {
        const addTermsBtn = document.getElementById('add-terms-to-concept-btn');
        if (addTermsBtn) {
            addTermsBtn.addEventListener('click', () => {
                this.showAddTermsToConceptModal();
            });
        }
    }
    
    removeTermFromConcept(termName) {
        if (this.currentItem && this.currentView === 'concepts') {
            this.currentItem.terms = this.currentItem.terms.filter(t => t.term !== termName);
            this.renderConceptDetails(this.currentItem);
            
            // Update the table to reflect changes
            this.renderCurrentView();
            
            // Update the concept filter dropdown if we're in terms view
            this.populateConceptFilter();
        }
    }
    
    toggleEditMode() {
        this.isEditing = !this.isEditing;
        
        if (this.isEditing) {
            document.getElementById('edit-item-btn').innerHTML = `
                <span class="material-icons">cancel</span>
                Cancel
            `;
            document.getElementById('edit-item-btn').classList.remove('btn-primary');
            document.getElementById('edit-item-btn').classList.add('btn-secondary');
        } else {
            document.getElementById('edit-item-btn').innerHTML = `
                <span class="material-icons">edit</span>
                Edit
            `;
            document.getElementById('edit-item-btn').classList.remove('btn-secondary');
            document.getElementById('edit-item-btn').classList.add('btn-primary');
        }
        
        // Re-render the details with the new mode
        if (this.currentItem) {
            if (this.currentView === 'concepts') {
                this.renderConceptDetails(this.currentItem);
            } else {
                this.renderTermDetails(this.currentItem);
            }
        }
    }
    
    addConceptEditFormListeners() {
        const form = document.getElementById('concept-edit-form');
        const cancelBtn = document.getElementById('cancel-edit-btn');
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveConceptChanges();
        });
        
        cancelBtn.addEventListener('click', () => {
            this.toggleEditMode();
        });
    }
    
    addTermEditFormListeners() {
        const form = document.getElementById('term-edit-form');
        const cancelBtn = document.getElementById('cancel-edit-btn');
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveTermChanges();
        });
        
        cancelBtn.addEventListener('click', () => {
            this.toggleEditMode();
        });
    }
    
    saveConceptChanges() {
        const name = document.getElementById('edit-concept-name').value;
        const description = document.getElementById('edit-concept-description').value;
        const usage = document.getElementById('edit-concept-usage').value;
        const confidence = parseFloat(document.getElementById('edit-concept-confidence').value);
        
        // Update the concept object
        this.currentItem.conceptName = name;
        this.currentItem.conceptDescription = description;
        this.currentItem.usageContext = usage;
        this.currentItem.confidenceScore = confidence;
        
        // Update the table
        this.renderCurrentView();
        
        // Update the concept filter dropdown
        this.populateConceptFilter();
        
        // Exit edit mode
        this.toggleEditMode();
        
        // Show success message (optional)
        console.log('Concept updated successfully');
    }
    
    saveTermChanges() {
        const originalTerm = document.getElementById('edit-term-original').value;
        const termName = document.getElementById('edit-term-name').value;
        const altTerms = document.getElementById('edit-term-alt').value.split(',').map(t => t.trim()).filter(t => t);
        const definition = document.getElementById('edit-term-definition').value;
        const usage = document.getElementById('edit-term-usage').value;
        const notes = document.getElementById('edit-term-notes').value;
        const examples = document.getElementById('edit-term-examples').value;
        const relatedTerms = document.getElementById('edit-term-related').value.split(',').map(t => t.trim()).filter(t => t);
        const confidence = parseFloat(document.getElementById('edit-term-confidence').value);
        
        // Update the term object
        this.currentItem.originalTerm = originalTerm;
        this.currentItem.term = termName;
        this.currentItem.altTerms = altTerms;
        this.currentItem.definition = definition;
        this.currentItem.usageContext = usage;
        this.currentItem.additionalContext.notes = notes;
        this.currentItem.additionalContext.examples = examples;
        this.currentItem.additionalContext.relatedTerms = relatedTerms;
        this.currentItem.confidenceScore = confidence;
        
        // Update the table
        this.renderCurrentView();
        
        // Exit edit mode
        this.toggleEditMode();
        
        // Show success message (optional)
        console.log('Term updated successfully');
    }
    
    showAddTermsToConceptModal() {
        const allTerms = dataUtils.getAllTerms();
        const conceptTermNames = this.currentItem.terms.map(t => t.term);
        const availableTerms = allTerms.filter(term => !conceptTermNames.includes(term.term));
        
        const content = `
            <div class="form-group">
                <label>Select terms to add to concept:</label>
                <div class="multi-select-container">
                    <div class="search-box">
                        <span class="material-icons">search</span>
                        <input type="text" id="term-search-modal" placeholder="Search terms...">
                    </div>
                    <div class="picklist" id="terms-picklist">
                        ${availableTerms.map(term => `
                            <div class="picklist-item" data-term-id="${term.id}">
                                <div class="picklist-item-content">
                                    <div class="picklist-item-title">${term.term}</div>
                                    <div class="picklist-item-subtitle">${term.originalTerm}</div>
                                    <div class="picklist-item-description">${term.definition}</div>
                                </div>
                                <span class="material-icons picklist-checkbox">check_box_outline_blank</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
        this.showModal('Add Terms to Concept', content);
        
        // Add search functionality
        this.addTermSearchListener();
        
        // Add click handlers for picklist items
        this.addPicklistItemListeners();
    }
    
    addTermSearchListener() {
        const searchInput = document.getElementById('term-search-modal');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filterTermsInModal(e.target.value);
            });
        }
    }
    
    filterTermsInModal(query) {
        const picklistItems = document.querySelectorAll('#terms-picklist .picklist-item');
        const lowercaseQuery = query.toLowerCase();
        
        picklistItems.forEach(item => {
            const title = item.querySelector('.picklist-item-title').textContent.toLowerCase();
            const subtitle = item.querySelector('.picklist-item-subtitle').textContent.toLowerCase();
            const description = item.querySelector('.picklist-item-description').textContent.toLowerCase();
            
            if (title.includes(lowercaseQuery) || subtitle.includes(lowercaseQuery) || description.includes(lowercaseQuery)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    addPicklistItemListeners() {
        const picklistItems = document.querySelectorAll('#terms-picklist .picklist-item');
        picklistItems.forEach(item => {
            item.addEventListener('click', () => {
                item.classList.toggle('selected');
                const checkbox = item.querySelector('.picklist-checkbox');
                if (item.classList.contains('selected')) {
                    checkbox.textContent = 'check_box';
                } else {
                    checkbox.textContent = 'check_box_outline_blank';
                }
            });
        });
    }
    
    saveModal() {
        // Check if this is the add terms modal
        const picklistItems = document.querySelectorAll('#terms-picklist .picklist-item.selected');
        if (picklistItems.length > 0) {
            this.addSelectedTermsToConcept(picklistItems);
        }
        
        this.hideModal();
    }
    
    addSelectedTermsToConcept(selectedItems) {
        const allTerms = dataUtils.getAllTerms();
        const selectedTermIds = Array.from(selectedItems).map(item => item.dataset.termId);
        const selectedTerms = allTerms.filter(term => selectedTermIds.includes(term.id));
        
        // Add selected terms to the concept
        selectedTerms.forEach(term => {
            const conceptTerm = {
                term: term.term,
                definition: term.definition,
                usageContext: term.usageContext
            };
            this.currentItem.terms.push(conceptTerm);
        });
        
        // Re-render the concept details
        this.renderConceptDetails(this.currentItem);
        
        // Update the table to reflect changes
        this.renderCurrentView();
        
        // Update the concept filter dropdown if we're in terms view
        this.populateConceptFilter();
        
        console.log(`Added ${selectedTerms.length} terms to concept`);
    }
    
    // Modal Functions
    showModal(title, content) {
        document.getElementById('modal-title').textContent = title;
        document.getElementById('modal-body').innerHTML = content;
        document.getElementById('modal-overlay').classList.add('active');
    }
    
    hideModal() {
        document.getElementById('modal-overlay').classList.remove('active');
        this.editingItem = null;
    }
    
    saveModal() {
        // This would handle saving the form data
        // For now, just close the modal
        this.hideModal();
    }
    
    // Add/Edit Modals
    showAddItemModal() {
        if (this.currentView === 'concepts') {
            this.showAddConceptModal();
        } else {
            this.showAddTermModal();
        }
    }
    
    showEditItemModal() {
        if (this.currentView === 'concepts') {
            this.showEditConceptModal();
        } else {
            this.showEditTermModal();
        }
    }
    
    showAddConceptModal() {
        const content = `
            <div class="form-group">
                <label for="concept-name">Concept Name:</label>
                <input type="text" id="concept-name" required>
            </div>
            <div class="form-group">
                <label for="concept-description">Description:</label>
                <textarea id="concept-description" required></textarea>
            </div>
            <div class="form-group">
                <label for="concept-usage">Usage Context:</label>
                <input type="text" id="concept-usage" required>
            </div>
            <div class="form-group">
                <label for="concept-confidence">Confidence Score:</label>
                <input type="number" id="concept-confidence" min="0" max="1" step="0.01" value="0.8">
            </div>
        `;
        this.showModal('Add New Concept', content);
    }
    
    showEditConceptModal() {
        if (!this.currentItem) return;
        
        this.editingItem = this.currentItem;
        
        const content = `
            <div class="form-group">
                <label for="concept-name">Concept Name:</label>
                <input type="text" id="concept-name" value="${this.currentItem.conceptName}" required>
            </div>
            <div class="form-group">
                <label for="concept-description">Description:</label>
                <textarea id="concept-description" required>${this.currentItem.conceptDescription}</textarea>
            </div>
            <div class="form-group">
                <label for="concept-usage">Usage Context:</label>
                <input type="text" id="concept-usage" value="${this.currentItem.usageContext}" required>
            </div>
            <div class="form-group">
                <label for="concept-confidence">Confidence Score:</label>
                <input type="number" id="concept-confidence" min="0" max="1" step="0.01" value="${this.currentItem.confidenceScore}">
            </div>
        `;
        this.showModal('Edit Concept', content);
    }
    
    showAddTermModal() {
        const content = `
            <div class="form-group">
                <label for="term-original">Original Term:</label>
                <input type="text" id="term-original" required>
            </div>
            <div class="form-group">
                <label for="term-name">Term Name:</label>
                <input type="text" id="term-name" required>
            </div>
            <div class="form-group">
                <label for="term-alt">Alternative Terms (comma-separated):</label>
                <input type="text" id="term-alt" placeholder="alt1, alt2, alt3">
            </div>
            <div class="form-group">
                <label for="term-definition">Definition:</label>
                <textarea id="term-definition" required></textarea>
            </div>
            <div class="form-group">
                <label for="term-usage">Usage Context:</label>
                <input type="text" id="term-usage" required>
            </div>
            <div class="form-group">
                <label for="term-notes">Notes:</label>
                <textarea id="term-notes"></textarea>
            </div>
            <div class="form-group">
                <label for="term-examples">Examples:</label>
                <textarea id="term-examples"></textarea>
            </div>
            <div class="form-group">
                <label for="term-related">Related Terms (comma-separated):</label>
                <input type="text" id="term-related" placeholder="term1, term2, term3">
            </div>
            <div class="form-group">
                <label for="term-confidence">Confidence Score:</label>
                <input type="number" id="term-confidence" min="0" max="1" step="0.01" value="0.8">
            </div>
        `;
        this.showModal('Add New Term', content);
    }
    
    showEditTermModal() {
        if (!this.currentItem) return;
        
        this.editingItem = this.currentItem;
        
        const content = `
            <div class="form-group">
                <label for="term-original">Original Term:</label>
                <input type="text" id="term-original" value="${this.currentItem.originalTerm}" required>
            </div>
            <div class="form-group">
                <label for="term-name">Term Name:</label>
                <input type="text" id="term-name" value="${this.currentItem.term}" required>
            </div>
            <div class="form-group">
                <label for="term-alt">Alternative Terms (comma-separated):</label>
                <input type="text" id="term-alt" value="${this.currentItem.altTerms.join(', ')}" placeholder="alt1, alt2, alt3">
            </div>
            <div class="form-group">
                <label for="term-definition">Definition:</label>
                <textarea id="term-definition" required>${this.currentItem.definition}</textarea>
            </div>
            <div class="form-group">
                <label for="term-usage">Usage Context:</label>
                <input type="text" id="term-usage" value="${this.currentItem.usageContext}" required>
            </div>
            <div class="form-group">
                <label for="term-notes">Notes:</label>
                <textarea id="term-notes">${this.currentItem.additionalContext.notes}</textarea>
            </div>
            <div class="form-group">
                <label for="term-examples">Examples:</label>
                <textarea id="term-examples">${this.currentItem.additionalContext.examples}</textarea>
            </div>
            <div class="form-group">
                <label for="term-related">Related Terms (comma-separated):</label>
                <input type="text" id="term-related" value="${this.currentItem.additionalContext.relatedTerms.join(', ')}" placeholder="term1, term2, term3">
            </div>
            <div class="form-group">
                <label for="term-confidence">Confidence Score:</label>
                <input type="number" id="term-confidence" min="0" max="1" step="0.01" value="${this.currentItem.confidenceScore}">
            </div>
        `;
        this.showModal('Edit Term', content);
    }
}

// Initialize the app when the page loads
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new TerminologyApp();
});
