// Mock Data for Terms and Concepts

// Terms Data
const mockTerms = [
    {
        id: "term-1",
        originalTerm: "machine learning",
        term: "Machine Learning",
        altTerms: ["ML", "automated learning", "statistical learning"],
        definition: "A subset of artificial intelligence that enables computers to learn and improve from experience without being explicitly programmed.",
        usageContext: "Used in data science, AI research, and software development contexts",
        additionalContext: {
            notes: "Often confused with deep learning, which is a subset of ML",
            examples: "Recommendation systems, image recognition, natural language processing",
            relatedTerms: ["artificial intelligence", "deep learning", "neural networks", "data science"]
        },
        confidenceScore: 0.95
    },
    {
        id: "term-2",
        originalTerm: "artificial intelligence",
        term: "Artificial Intelligence",
        altTerms: ["AI", "machine intelligence", "cognitive computing"],
        definition: "The simulation of human intelligence in machines that are programmed to think and learn like humans.",
        usageContext: "Broad field encompassing various technologies and applications",
        additionalContext: {
            notes: "Umbrella term for many subfields including ML, NLP, computer vision",
            examples: "Chatbots, autonomous vehicles, medical diagnosis systems",
            relatedTerms: ["machine learning", "natural language processing", "computer vision", "robotics"]
        },
        confidenceScore: 0.92
    },
    {
        id: "term-3",
        originalTerm: "data science",
        term: "Data Science",
        altTerms: ["data analytics", "big data analytics", "data mining"],
        definition: "An interdisciplinary field that uses scientific methods, processes, algorithms and systems to extract knowledge and insights from data.",
        usageContext: "Applied across industries for decision-making and business intelligence",
        additionalContext: {
            notes: "Combines statistics, computer science, and domain expertise",
            examples: "Predictive modeling, customer segmentation, fraud detection",
            relatedTerms: ["machine learning", "statistics", "data mining", "business intelligence"]
        },
        confidenceScore: 0.88
    },
    {
        id: "term-4",
        originalTerm: "neural network",
        term: "Neural Network",
        altTerms: ["artificial neural network", "ANN", "neural net"],
        definition: "A computing system inspired by biological neural networks that constitute animal brains.",
        usageContext: "Core component of deep learning and many AI applications",
        additionalContext: {
            notes: "Composed of interconnected nodes (neurons) that process information",
            examples: "Image recognition, speech processing, language translation",
            relatedTerms: ["deep learning", "machine learning", "artificial intelligence", "backpropagation"]
        },
        confidenceScore: 0.90
    },
    {
        id: "term-5",
        originalTerm: "natural language processing",
        term: "Natural Language Processing",
        altTerms: ["NLP", "computational linguistics", "text analytics"],
        definition: "A subfield of linguistics, computer science, and artificial intelligence concerned with interactions between computers and human language.",
        usageContext: "Used in chatbots, translation services, and text analysis applications",
        additionalContext: {
            notes: "Focuses on enabling computers to understand, interpret, and generate human language",
            examples: "Google Translate, Siri, sentiment analysis, text summarization",
            relatedTerms: ["machine learning", "computational linguistics", "text mining", "speech recognition"]
        },
        confidenceScore: 0.87
    },
    {
        id: "term-6",
        originalTerm: "cloud computing",
        term: "Cloud Computing",
        altTerms: ["cloud services", "cloud infrastructure", "on-demand computing"],
        definition: "The delivery of computing services including servers, storage, databases, networking, software, analytics, and intelligence over the Internet.",
        usageContext: "Modern IT infrastructure and software delivery model",
        additionalContext: {
            notes: "Enables on-demand access to shared computing resources",
            examples: "AWS, Google Cloud, Microsoft Azure, SaaS applications",
            relatedTerms: ["infrastructure as a service", "platform as a service", "software as a service", "virtualization"]
        },
        confidenceScore: 0.94
    },
    {
        id: "term-7",
        originalTerm: "blockchain",
        term: "Blockchain",
        altTerms: ["distributed ledger", "cryptocurrency technology", "decentralized database"],
        definition: "A distributed ledger technology that maintains a continuously growing list of records, called blocks, which are linked and secured using cryptography.",
        usageContext: "Used in cryptocurrency, supply chain, and secure transaction applications",
        additionalContext: {
            notes: "Provides transparency, immutability, and decentralization",
            examples: "Bitcoin, Ethereum, supply chain tracking, smart contracts",
            relatedTerms: ["cryptocurrency", "distributed ledger", "smart contracts", "decentralization"]
        },
        confidenceScore: 0.85
    },
    {
        id: "term-8",
        originalTerm: "internet of things",
        term: "Internet of Things",
        altTerms: ["IoT", "connected devices", "smart devices"],
        definition: "A network of physical objects that are embedded with sensors, software, and other technologies for the purpose of connecting and exchanging data with other devices and systems.",
        usageContext: "Smart homes, industrial automation, and connected infrastructure",
        additionalContext: {
            notes: "Enables automation and data collection from everyday objects",
            examples: "Smart thermostats, fitness trackers, industrial sensors, connected cars",
            relatedTerms: ["smart devices", "sensors", "connectivity", "automation"]
        },
        confidenceScore: 0.89
    },
    {
        id: "term-9",
        originalTerm: "cybersecurity",
        term: "Cybersecurity",
        altTerms: ["information security", "cyber security", "IT security"],
        definition: "The practice of protecting systems, networks, and programs from digital attacks.",
        usageContext: "Critical for protecting organizational and personal digital assets",
        additionalContext: {
            notes: "Encompasses multiple layers of protection across all digital touchpoints",
            examples: "Firewalls, encryption, access controls, incident response",
            relatedTerms: ["information security", "network security", "data protection", "risk management"]
        },
        confidenceScore: 0.91
    },
    {
        id: "term-10",
        originalTerm: "big data",
        term: "Big Data",
        altTerms: ["large datasets", "massive data", "data analytics"],
        definition: "Extremely large data sets that may be analyzed computationally to reveal patterns, trends, and associations.",
        usageContext: "Business intelligence, research, and decision-making applications",
        additionalContext: {
            notes: "Characterized by volume, velocity, variety, and veracity",
            examples: "Social media data, sensor data, transaction records, web logs",
            relatedTerms: ["data analytics", "data science", "machine learning", "data mining"]
        },
        confidenceScore: 0.86
    },
    {
        id: "term-11",
        originalTerm: "devops",
        term: "DevOps",
        altTerms: ["development operations", "agile operations", "continuous delivery"],
        definition: "A set of practices that combines software development and IT operations to shorten the systems development life cycle.",
        usageContext: "Software development and IT operations methodology",
        additionalContext: {
            notes: "Emphasizes collaboration, automation, and continuous improvement",
            examples: "CI/CD pipelines, infrastructure as code, monitoring and logging",
            relatedTerms: ["continuous integration", "continuous deployment", "agile", "infrastructure as code"]
        },
        confidenceScore: 0.88
    },
    {
        id: "term-12",
        originalTerm: "microservices",
        term: "Microservices",
        altTerms: ["microservice architecture", "service-oriented architecture", "distributed services"],
        definition: "An architectural approach where applications are built as a collection of loosely coupled, independently deployable services.",
        usageContext: "Modern software architecture for scalable and maintainable applications",
        additionalContext: {
            notes: "Each service focuses on a specific business capability",
            examples: "Netflix, Amazon, Uber's service architectures",
            relatedTerms: ["service-oriented architecture", "API", "containerization", "distributed systems"]
        },
        confidenceScore: 0.83
    }
];

// Concepts Data
const mockConcepts = [
    {
        id: "concept-1",
        conceptName: "Artificial Intelligence Technologies",
        conceptDescription: "A comprehensive category covering all technologies and methodologies related to artificial intelligence and machine learning.",
        usageContext: "Used in technology discussions, research papers, and business strategy planning",
        terms: [
            {
                term: "Machine Learning",
                definition: "A subset of artificial intelligence that enables computers to learn and improve from experience without being explicitly programmed.",
                usageContext: "Used in data science, AI research, and software development contexts"
            },
            {
                term: "Artificial Intelligence",
                definition: "The simulation of human intelligence in machines that are programmed to think and learn like humans.",
                usageContext: "Broad field encompassing various technologies and applications"
            },
            {
                term: "Neural Network",
                definition: "A computing system inspired by biological neural networks that constitute animal brains.",
                usageContext: "Core component of deep learning and many AI applications"
            },
            {
                term: "Natural Language Processing",
                definition: "A subfield of linguistics, computer science, and artificial intelligence concerned with interactions between computers and human language.",
                usageContext: "Used in chatbots, translation services, and text analysis applications"
            }
        ],
        confidenceScore: 0.93
    },
    {
        id: "concept-2",
        conceptName: "Data Management and Analytics",
        conceptDescription: "Technologies and practices for collecting, storing, processing, and analyzing data to extract meaningful insights.",
        usageContext: "Business intelligence, research, and decision-making applications",
        terms: [
            {
                term: "Data Science",
                definition: "An interdisciplinary field that uses scientific methods, processes, algorithms and systems to extract knowledge and insights from data.",
                usageContext: "Applied across industries for decision-making and business intelligence"
            },
            {
                term: "Big Data",
                definition: "Extremely large data sets that may be analyzed computationally to reveal patterns, trends, and associations.",
                usageContext: "Business intelligence, research, and decision-making applications"
            }
        ],
        confidenceScore: 0.89
    },
    {
        id: "concept-3",
        conceptName: "Cloud and Infrastructure",
        conceptDescription: "Modern computing infrastructure and delivery models that enable scalable and flexible IT services.",
        usageContext: "IT infrastructure planning, software deployment, and service delivery",
        terms: [
            {
                term: "Cloud Computing",
                definition: "The delivery of computing services including servers, storage, databases, networking, software, analytics, and intelligence over the Internet.",
                usageContext: "Modern IT infrastructure and software delivery model"
            },
            {
                term: "Microservices",
                definition: "An architectural approach where applications are built as a collection of loosely coupled, independently deployable services.",
                usageContext: "Modern software architecture for scalable and maintainable applications"
            },
            {
                term: "DevOps",
                definition: "A set of practices that combines software development and IT operations to shorten the systems development life cycle.",
                usageContext: "Software development and IT operations methodology"
            }
        ],
        confidenceScore: 0.87
    },
    {
        id: "concept-4",
        conceptName: "Security and Privacy",
        conceptDescription: "Technologies and practices focused on protecting digital assets, data, and systems from threats and ensuring privacy.",
        usageContext: "Risk management, compliance, and digital asset protection",
        terms: [
            {
                term: "Cybersecurity",
                definition: "The practice of protecting systems, networks, and programs from digital attacks.",
                usageContext: "Critical for protecting organizational and personal digital assets"
            }
        ],
        confidenceScore: 0.91
    },
    {
        id: "concept-5",
        conceptName: "Emerging Technologies",
        conceptDescription: "Cutting-edge technologies that are shaping the future of digital transformation and innovation.",
        usageContext: "Technology strategy, innovation planning, and future readiness",
        terms: [
            {
                term: "Blockchain",
                definition: "A distributed ledger technology that maintains a continuously growing list of records, called blocks, which are linked and secured using cryptography.",
                usageContext: "Used in cryptocurrency, supply chain, and secure transaction applications"
            },
            {
                term: "Internet of Things",
                definition: "A network of physical objects that are embedded with sensors, software, and other technologies for the purpose of connecting and exchanging data with other devices and systems.",
                usageContext: "Smart homes, industrial automation, and connected infrastructure"
            }
        ],
        confidenceScore: 0.84
    }
];

// Helper functions for data manipulation
const dataUtils = {
    // Get all terms
    getAllTerms: () => [...mockTerms],
    
    // Get all concepts
    getAllConcepts: () => [...mockConcepts],
    
    // Get term by ID
    getTermById: (id) => mockTerms.find(term => term.id === id),
    
    // Get concept by ID
    getConceptById: (id) => mockConcepts.find(concept => concept.id === id),
    
    // Search terms
    searchTerms: (query) => {
        if (!query) return mockTerms;
        const lowercaseQuery = query.toLowerCase();
        return mockTerms.filter(term => 
            term.term.toLowerCase().includes(lowercaseQuery) ||
            term.originalTerm.toLowerCase().includes(lowercaseQuery) ||
            term.definition.toLowerCase().includes(lowercaseQuery) ||
            term.altTerms.some(alt => alt.toLowerCase().includes(lowercaseQuery))
        );
    },
    
    // Search concepts
    searchConcepts: (query) => {
        if (!query) return mockConcepts;
        const lowercaseQuery = query.toLowerCase();
        return mockConcepts.filter(concept => 
            concept.conceptName.toLowerCase().includes(lowercaseQuery) ||
            concept.conceptDescription.toLowerCase().includes(lowercaseQuery) ||
            concept.usageContext.toLowerCase().includes(lowercaseQuery)
        );
    },
    
    // Sort terms
    sortTerms: (terms, sortBy) => {
        return [...terms].sort((a, b) => {
            switch (sortBy) {
                case 'name':
                    return a.term.localeCompare(b.term);
                case 'confidence':
                    return b.confidenceScore - a.confidenceScore;
                default:
                    return 0;
            }
        });
    },
    
    // Sort concepts
    sortConcepts: (concepts, sortBy) => {
        return [...concepts].sort((a, b) => {
            switch (sortBy) {
                case 'name':
                    return a.conceptName.localeCompare(b.conceptName);
                case 'confidence':
                    return b.confidenceScore - a.confidenceScore;
                default:
                    return 0;
            }
        });
    },
    
    // Filter terms by concept
    filterTermsByConcept: (terms, conceptId) => {
        if (!conceptId) return terms;
        const concept = mockConcepts.find(c => c.id === conceptId);
        if (!concept) return terms;
        
        const conceptTermNames = concept.terms.map(t => t.term);
        return terms.filter(term => conceptTermNames.includes(term.term));
    },
    
    // Get confidence badge class
    getConfidenceBadgeClass: (score) => {
        if (score >= 0.9) return 'confidence-badge';
        if (score >= 0.7) return 'confidence-badge medium';
        return 'confidence-badge low';
    },
    
    // Get confidence percentage
    getConfidencePercentage: (score) => {
        return Math.round(score * 100);
    }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { mockTerms, mockConcepts, dataUtils };
}
